export default [
    {
      "id": 1,
      "nguoidanhgia":"nguyenvanA",
      "nguoiduocdanhgia":"nguyenvanB",
      "thoihan":"19/05/2020"
    },
    {
      "id": 2,
      "nguoidanhgia":"nguyenvaC",
      "nguoiduocdanhgia":"nguyenvaD",
      "thoihan":"19/05/2020"
    },
    {
      "id": 3,
      "nguoidanhgia":"nguyenE",
      "nguoiduocdanhgia":"nguyenvF",
      "thoihan":"19/05/2020"
    },
  ]