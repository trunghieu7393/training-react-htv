export default [
    {
        label: 'Báo cáo',
        url:'BaoCao'
    },
    {
        label: 'Báo cáo chi tiết',
        url:'/BaoCaoChiTiet'
    },
    {
        label:'Câu hỏi',
        url:'CauHoi'
    },
    {
        label: 'Đăng nhập',
        url:'DangNhap'
    },
    {
        label: 'Đánh giá mentor',
        url:'/DanhGiaMentor'
    },
    {
        label:'Danh mục',
        url:'DanhMuc'
    },
    {
        label:'Review câu hỏi',
        url:'ReviewCauHoi'
    },
    {
        label: 'Sửa câu hỏi',
        url:'SuaCauHoi'
    },
    {
        label: 'Tất cả câu hỏi',
        url:'/TatCaCauHoi'
    },
    {
        label:'Trang đánh giá',
        url:'TrangDanhGia'
    }
]

